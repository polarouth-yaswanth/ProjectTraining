package com.yaswanth;


public class Main {
	public static void main(String args[]) {
	
		Account yAccount = new Account("121212",0,"y","y@xyz.com","1212121");

        yAccount.DepositMoney(50);
        yAccount.DepositMoney(150);

        yAccount.WithDrawMoney(100);
    
    }
		
	}
