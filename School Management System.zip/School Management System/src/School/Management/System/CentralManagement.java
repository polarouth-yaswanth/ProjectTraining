package School.Management.System;

import java.util.ArrayList;
import java.util.List;

public class CentralManagement {

	public static void main(String args[]) {
		Teacher john = new Teacher(1,"j",20000);
		Teacher kim = new Teacher(2,"k",422222);
		Teacher nike = new Teacher(3,"n",52222431);
		
		
		List<Teacher> Tl = new ArrayList<>();
		Tl.add(john);
		Tl.add(kim);
		Tl.add(nike);
		
		
		
		Student s1 = new Student(1,"s1",9);
		Student s2 = new Student(2,"s2",10);
		Student s3 = new Student(3,"s3",11);
		
		
		List<Student> Sl = new ArrayList<>();
		Sl.add(s1);
		Sl.add(s2);
		Sl.add(s3);		
		
		
		School sc = new School(Tl,Sl);
		
		s1.payFees(50000);
		s2.payFees(200000);
		System.out.println("Total Money Earned "+sc.getTotalmoneyEarned()+ "$");
		
		john.recieveSalary(john.getSalary());
		System.out.println("School credited salary to " + john.getName()+" With $"+sc.getTotalmoneyEarned());
		
		
		
		
		
		
		
		
		
	}
}
