package com.yaswanth;

public interface Telephone {

	void powerOn();
	void dial(String phoneNumber);
	void answer();
	boolean callphone(String phoneNumber);
	boolean isRinging();
}
