package com.yaswanth;

public class Main {

	
	public static void main(String[] args) {
		DeskPhone dp = new DeskPhone("982323");
		dp.powerOn();
		dp.answer();
		dp.callphone("982323");
		dp.dial("1234555");
		
	}
}