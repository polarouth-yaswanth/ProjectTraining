package com.yaswanth;

public class DeskPhone implements Telephone {
   
	private String myNumber;
	private boolean isRinging;
	
	
	public DeskPhone(String myNumber) {
		this.myNumber = myNumber;
	}
	
	public DeskPhone() {
	}


	@Override
	public void powerOn() {
		// TODO Auto-generated method stub
		System.out.println("Deskphone is always on due to wireless charging");
		
	}


	@Override
	public void dial(String phoneNumber) {
		// TODO Auto-generated method stub
		System.out.println("This number is "+phoneNumber+ " now calling on Deskphone");
	}


	@Override
	public void answer() {
		// TODO Auto-generated method stub
		if(isRinging) {
			System.out.println("Picked up the call");
		}
		else {
			System.out.println("Phone is not ringing");
		}
	}


	@Override
	public boolean callphone(String phoneNumber) {
		if(phoneNumber == myNumber) {
			isRinging = true;
			System.out.println("phone ringing");
		}
		else {
			isRinging=false;
		}
		return isRinging;
	}


	@Override
	public boolean isRinging() {
		// TODO Auto-generated method stub
		return isRinging;
	}
	
	
}
