package com.depobinj.in;

public interface Cheat {
   public void cheat();
}
