package com.depobinj.in;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	
public static void main(String[] args) {
	
	/*Student student = new Student();
	Mathcheat math = new Mathcheat();
	student.setM(math);*/
	//student.startExam();
	
	
	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	Student stud = context.getBean("student",Student.class);
	System.out.println("Xml loaded successfully");
    stud.Cheating();
}
}
