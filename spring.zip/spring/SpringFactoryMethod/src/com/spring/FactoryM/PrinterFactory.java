package com.spring.FactoryM;

public class PrinterFactory {
    public static Printer getPrinter() {
    	return new Printer();
    }
}
