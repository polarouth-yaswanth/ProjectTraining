package com.spring.FactoryM;

public class Printer {
	public void printBalanceInfo(String Balance) {
		System.out.println("The printer has printed balance info:"+Balance);
	}

}
