package com.coninj.pratice;

import org.springframework.context.ApplicationContext;


import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Exam {
  public static void main(String[] args) {
  ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml"); 
	Student su = context.getBean("stud",Student.class);
	su.doNo();
    Student1 student1 = context.getBean("stud1",Student1.class);
    student1.printData();
	
}
}
