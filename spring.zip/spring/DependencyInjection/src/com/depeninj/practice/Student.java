package com.depeninj.practice;

public class Student {
     
	private String studentName;
	private int idNumber;

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public void setidNumber(int idNumber) {
		this.idNumber = idNumber;
	}

	public void setstudentName(String studentName) {
		this.studentName = studentName;
	}
	
	public void doNo() {
		System.out.println("Student name is: " +studentName + " and id number is " +idNumber);
	}
	
	
	
}
