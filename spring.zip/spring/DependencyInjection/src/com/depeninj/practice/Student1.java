package com.depeninj.practice;

public class Student1 {
    private String student1Name;
    private int idNumber;
    
    public void setidNumber(int idNumber) {
    	this.idNumber = idNumber;
    }
	public void setStudent1Name(String student1Name) {
		this.student1Name = student1Name;
	}
    
    public void printData() {
    	System.out.println("Student name is: "+student1Name + " and id number is " +idNumber);
      
    }
    
}
