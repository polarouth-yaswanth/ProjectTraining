package com.cg.spring;

public class Airtel implements Sim {
	public Airtel() {
		System.out.println("Airtel object is created");
	}
	
	  public void Calling() {
	    	 System.out.println("I am calling through airtel");
	}
	     public void Data() {
	    	 System.out.println("I am draining my data");
	     }

}
