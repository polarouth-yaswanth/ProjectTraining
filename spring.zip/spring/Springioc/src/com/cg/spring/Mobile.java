//  <bean id= "jio" class="com.cg.spring.Jio"></bean>      Line of beans.xml


package com.cg.spring;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mobile {

	public static void main(String[] args) {
		/*Airtel airtel = new Airtel();
		 airtel.Calling();
		 airtel.Data();
		 Jio jio = new Jio();
		 jio.Calling();
		 jio.Data();*/
		//Instead I can go for interface  method
		//Sim sim = new Airtel();
		//sim.Calling();
		// sim.Data();
		//Instead i can use spring
		/*	Airtel a=(Airtel)context.getBean("airtel"); //Type-casting approach
		Jio j=context.getBean("jio",Jio.class);    //Another approach
		a.Calling();
		a.Data(); 
		j.Calling();
		j.Data();
		System.out.println("These sims are working");*/
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml"); 
		System.out.println("...Config Loaded.....");
		Sim a=context.getBean("sim1",Sim.class);
		a.Calling();
		a.Data();
		Sim j = context.getBean("sim2",Sim.class);
		j.Calling();
		j.Data();

	}
}


