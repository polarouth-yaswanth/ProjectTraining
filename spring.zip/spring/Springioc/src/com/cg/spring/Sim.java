package com.cg.spring;

public interface Sim {
	
	 void Calling();
	 void Data();

}
